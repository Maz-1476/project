public interface PrintingBook {

    void printBook(Book book);
}
