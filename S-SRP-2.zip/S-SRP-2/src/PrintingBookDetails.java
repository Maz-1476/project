public class PrintingBookDetails implements PrintingBook{

    @Override
    public void printBook(Book book) {

        System.out.println("-----Book Details-----");
        System.out.println("The Book Title: " + book.getBookTitle());
        System.out.println("The Author Name: " + book.getAuthorName());
        System.out.println("The ISBN Number: " + book.getIsbnNumber("CSE69"));

    }
}
