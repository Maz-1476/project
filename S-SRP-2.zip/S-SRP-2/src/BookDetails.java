public class BookDetails{
    public static void main(String[] args){

        Book book = new Book();
        book.setBookTitle("Advance Java Book");
        book.setAuthorName("Zubair Mazumder");
        book.setIsbnNumber("CSE69");

        PrintingBookDetails printingBookDetails = new PrintingBookDetails();
        printingBookDetails.printBook(book);

        BookSaveInDatabase bookSaveInDatabase = new BookSaveInDatabase();
        bookSaveInDatabase.addBook(book);
    }
}