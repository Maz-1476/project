public class BookSaveInDatabase implements BookDatabase{
    @Override
    public void addBook(Book book) {

        System.out.println("-----Book Add In The Database-----");
        System.out.println("Book " + book.getBookTitle() + " has been added to the database " +
                "by Author " + book.getAuthorName() +
                "and The ISBN Number is:" + book.getIsbnNumber("CSE69"));

    }
}
