public interface BookDatabase {

    void addBook(Book book);
}
