public class Book {

    public String bookTitle;

    public String authorName;

    public String isbnNumber;;

    public Book(){

    }

    public Book(String bookTitle, String authorName, String isbnNumber) {
        this.bookTitle = bookTitle;
        this.authorName = authorName;
        this.isbnNumber = isbnNumber;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setIsbnNumber(String isbnNumber) {
        this.isbnNumber = isbnNumber;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getIsbnNumber(String cse69) {
        return isbnNumber;
    }
}
